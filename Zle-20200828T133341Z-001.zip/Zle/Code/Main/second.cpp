#include<iostream>
#include<std::string>

int main(){
std::string str="This is a Zole";
std::cout<<str;

return 0;
}