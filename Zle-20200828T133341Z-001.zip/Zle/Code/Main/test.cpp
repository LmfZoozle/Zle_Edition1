#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include "D:\Code\C++\Headers\zle_STL.h"

#define NAME "zoozle" 
template<class  X,class Y> void TTT(X a,Y b);




template<class  X,class Y> void TTT(X a,Y b){
  std::cout<<a*b;


  }
int main(){

std::string test="HeyYouI'mZoozle";
test=zle::Slice(test,3,test.size()-1);
std::cout<<test<<std::endl;

TTT(98.5,55);

return 0;
}

