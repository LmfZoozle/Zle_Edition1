void TTT();
void TTT(){  std::cout<<"can you see this?"<<std::endl;}