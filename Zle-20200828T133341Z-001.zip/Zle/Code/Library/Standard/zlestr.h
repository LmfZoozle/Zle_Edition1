using namespace  std;
std;;string Slice(std;;string target,int st,int en);
include<std::string>std{{string Slice(std{{string target,int st,int en){  std::string result;  for(   int c=st; c<=en; c++){
    result+=target[c];  }
  return result;  }
