#pragma once
#include <iostream>
#include<fstream>
#include<sstream>

#include<iomanip>
#include<string>
#include<vector>
#include<list>
#include<map>

#include "global.h"

#define FE "Fatal Error: "
#define SE "Syntax Error: "


namespace E_M {
	void LackArg(int argc);
	void NotZLE(std::string name);
	void NotCPP(std::string name);
	void FailedOpen();
	void FailedCreate();
	void ImportSemi(int line);
	void DefineSemi(int line);
	void UnknownFor(int line);
	void MyportSemi(int line);
	void TemplateSynSin(int line);
	void FullHeaderFailed_Read(std::string name);
	void FullHeaderFailed_Write(std::string name);
	void NoLibraryHeader(std::string name);
	void LibraryHeaderFailed_Read(std::string name);
	void LibraryHeaderFailed_Write(std::string name);
	void ConfingError();
}

void E_M::LackArg(int argc) {
	std::cout << FE << "Code 1:LackArg" << std::endl;
	std::cout << "This application requires 1 arguments" << std::endl;
	std::cout << "But there are only " << argc - 1 << std::endl;
	exit(1);
}

void E_M::NotZLE(std::string name) {
	std::string::size_type findzle = name.find(".zle");
	if (findzle == std::string::npos) {
		std::cout << FE << "Code 2:NotZLE" << std::endl;
		std::cout << "Argument2 need to be .zle file" << std::endl;
		exit(2);
	}
}

void E_M::NotCPP(std::string name) {
	std::string::size_type findzle = name.find(".cpp");
	if (findzle == std::string::npos) {
		std::cout << FE << "Code 3:NotCPP" << std::endl;
		std::cout << "Argument3 need to be .cpp file" << std::endl;
		exit(3);
	}
}


void E_M::FailedOpen() {
	std::cout << FE<<"Code 4:FailedOpen" << std::endl;
	std::cout << "Couldn't open the source file" << std::endl;
	exit(4);
}

void E_M::FailedCreate() {
	std::cout << FE << "Code 5:FailedCreate" << std::endl;
	std::cout << "Couldn't creat the C++ source file" << std::endl;
	exit(5);
}

void E_M::ImportSemi(int line) {
	std::cout << SE << "ImportSemi  Line" << line << " , Code 6" << std::endl;
	std::cout << "Import statement dosn't require semicolon" << std::endl;
	exit(6);
}

void E_M::DefineSemi(int line) {
	std::cout << SE << "DefineSemi  Line" << line << " , Code 7" << std::endl;
	std::cout << "Define statement dosn't require semicolon" << std::endl;
	exit(7);
}

void E_M::UnknownFor(int line) {
	std::cout << SE << "UnknownFor  Line" << line << " , Code 8" << std::endl;
	std::cout << "Syntax of For statement is wrong" << std::endl;
	exit(8);
}

void E_M::MyportSemi(int line) {
	std::cout << SE << "MyportSemi  Line" << line << " , Code 9" << std::endl;
	std::cout << "Myport statement doesn't require semicolon" << std::endl;
	exit(9);
}

void E_M::TemplateSynSin(int line) {
	std::cout << SE << "TemplateSynSin  Line" << line << " , Code 10" << std::endl;
	std::cout << "Template function statement is wrong" << std::endl;
	exit(10);
}

void E_M::FullHeaderFailed_Read(std::string name) {
	std::cout << FE << "FullHeaderFailed-Read  name:" <<name << " , Code 11" << std::endl;
	std::cout << "Couldn't open the Header file for read" << std::endl;
	exit(11);
}

void E_M::FullHeaderFailed_Write(std::string name) {
	std::cout << FE << "FullHeaderFailed-Write  name:" << name << " , Code 12" << std::endl;
	std::cout << "Couldn't create the Header file for write" << std::endl;
	exit(12);
}

void E_M::NoLibraryHeader(std::string name) {
	std::cout << FE << "NoLibraryHeader  name:" << name << " , Code 13" << std::endl;
	std::cout << "There is no such a file in Library folder" << std::endl;
	exit(13);
}

void E_M::LibraryHeaderFailed_Read(std::string name) {
	std::cout << FE << "LibraryHeaderFailed-Read  name:" << name << " , Code 14" << std::endl;
	std::cout << "Couldn't open the Header file for read" << std::endl;
	exit(14);
}

void E_M::LibraryHeaderFailed_Write(std::string name) {
	std::cout << FE << "LibraryHeaderFailed-Write  name:" << name << " , Code 15" << std::endl;
	std::cout << "Couldn't create the Header file for write" << std::endl;
	exit(15);
}

void E_M::ConfingError() {
	std::cout << FE << "ConfingError" << " , Code 16" << std::endl;
	std::cout << "Config is wrong" << std::endl;
	exit(16);
}