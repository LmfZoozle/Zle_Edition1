#pragma once

#include <iostream>
#include<fstream>
#include<sstream>

#include<iomanip>
#include<string>
#include<vector>
#include<list>
#include<map>
#include<set>
#include<unordered_map>
#include<unordered_set>
#include<algorithm>
#include<utility>
#include<functional>
#include<regex>
#include "global.h"

#include "D:\\Code\\C++\\Headers\zle_STL.h"
//#include "Main_Function.h"
#include "Error_Message.h"

#define NM "NOTHNIGMATCH"
#define NLS "NULLSENTENCE"
#define RE return 999;
//extern std::ofstream T_File;

namespace T_F {
	int Search(std::string body, std::string tar);
	bool Search(std::string body, char tar);
	int Search(std::string body, std::string tar, int& position);
	std::string Erase(std::string body, std::string tar);
	int PatternIF(std::vector <std::string>& body, int now);
	std::string OnceChange(std::string body, char from, char to);
	std::string ChtoStr(std::string body, char from, std::string to);
	int PatternFor(std::string body);
	std::string OnceFormat(std::string body, std::string from, std::string to);
	std::string AllFormat(std::string body, std::string from, std::string to);
	void MacroSTD(std::string& EachLine);

}

int T_F::Search(std::string body, std::string tar) {
	std::string::size_type findtar = body.find(tar);
	if (findtar == std::string::npos) {
		return 0;
	}
	else {
		return (int)findtar;
	}
}

bool T_F::Search(std::string body, char tar) {
	for (int c = 0; c < body.size(); c++) {
		if (body[c] == tar) {
			return true;
		}
	}
	return false;
}


int T_F::Search(std::string body, std::string tar, int& position) {
	//position = -1;
	std::string::size_type findtar = body.find(tar);
	if (findtar == std::string::npos) {
		return -1;
	}
	else {
		return (int)findtar;
		position= (int)findtar;
	}
}


std::string T_F::Erase(std::string body, std::string tar) {
	std::string temp;
	std::string::size_type finder = body.find(tar);
	if (finder != std::string::npos) {
		temp = zle::Slice(body, finder + tar.size(), body.size() - 1);
		body = zle::Slice(body, 0, finder - 1);
		return body + temp;
	}
	else {
		return 0;
	}
}

int T_F::PatternIF(std::vector <std::string>& body,int now) {
	int tabcount = 0;
	int endtab = 0;
	for (int c = 0; c < body[now].size(); c++) {
		if (body[now][c] == ' ') {
			tabcount++;
		}
		else {
			//std::cout <<"tabcount"<< tabcount << std::endl;
			break;
		}
	}

	for (int c = 0; c < body[now+1].size(); c++) {
		//std::cout << body[now + 1] << std::endl;
		if (body[now + 1][c] == ' ') {
		//	std::cout << "tab������܂��您��\n";
			endtab++;
		}
		else {
			std::cout << "endtab" << endtab << std::endl;
			break;
		}
	}

	if (tabcount >= endtab) {
	//	std::cout << "same" << std::endl;
		return 0;
	}
	else {
	//	std::cout << "notsame" << std::endl;
		return 1;
	}

}

std::string T_F::OnceChange(std::string body, char from, char to) {
	for (int c = 0; c < body.size(); c++) {
		if (body[c] == from) {
			body[c] = to;
			return body;
		}
	}
	return NLS;
}

std::string T_F::ChtoStr(std::string body, char from, std::string to) {
	for (int s = 0; s < body.size(); s++) {
		if (body[s] == from) {
			body[s] = to[0];
			body.insert(s + 1, zle::Slice(to, 1, to.size() - 1));
			return body;
		}

	}
	return NLS;
}
// for int t in �z��
int T_F::PatternFor(std::string body) {
	int ch = -99;
	if (T_F::Search(body, "range", ch) != -1) {
		return 1;
	}
	else if(T_F::Search(body, "of", ch) != -1){
		return 0;
	}
	else {
		return -1;
	}
}

std::string T_F::OnceFormat(std::string body, std::string from, std::string to) {
	std::string::size_type finder = body.find(from);
	if (finder != std::string::npos) {
		body = T_F::Erase(body, from);
		body = body.insert(finder, to);
		return body;
	}
	else {
		return body;
	}
}

std::string T_F::AllFormat(std::string body, std::string from, std::string to) {
	std::vector<std::string::size_type> finder;
	int erasetime = 0;
	if (body.find(from) == std::string::npos) {
		return body;
	}


	while (1) {
		std::string::size_type temp = body.find(from);
		if (temp == std::string::npos) {
			break;
		}
		finder.emplace_back(temp + erasetime *from.size());
		body = T_F::Erase(body, from);
		erasetime++;
	}
	int insertime = 0;
	for (int c = 0; c < erasetime; c++) {
		body = body.insert(finder[c]+insertime*(to.size()-from.size()), to);
		insertime++;
	}
	return body;
}


void T_F::MacroSTD(std::string& EachLine) {

	EachLine = T_F::AllFormat(EachLine, "std::string", "string");
	EachLine = T_F::AllFormat(EachLine, "string", "std::string");

	EachLine = T_F::AllFormat(EachLine, "std::vector", "vector");
	EachLine = T_F::AllFormat(EachLine, "vector", "std::vector");

	EachLine = T_F::AllFormat(EachLine, "std::cout", "cout");
	EachLine = T_F::AllFormat(EachLine, "cout", "std::cout");

	EachLine = T_F::AllFormat(EachLine, "std::cin", "cin");
	EachLine = T_F::AllFormat(EachLine, "cin", "std::cin");

	EachLine = T_F::AllFormat(EachLine, "std::endl", "endl");
	EachLine = T_F::AllFormat(EachLine, "endl", "std::endl");

	EachLine = T_F::AllFormat(EachLine, "std::ifstream", "ifstream");
	EachLine = T_F::AllFormat(EachLine, "ifstream", "std::ifstream");

	EachLine = T_F::AllFormat(EachLine, "std::ofstream", "ofstream");
	EachLine = T_F::AllFormat(EachLine, "ofstream", "std::ofstream");
}

