#pragma once
int FORCOUNTER = 0;
std::vector<std::string> Code;
std::vector<std::string> T_Code;
std::string STD_Z;
std::string ADD_Z;
std::vector<std::string> STD_C;
std::string FilePath;
std::string FileName;
