//2020�N6��25��21��33���@����J�n�@
//Zoozle Transpiler

#include <iostream>
#include<fstream>
#include<sstream>

#include<iomanip>
#include<string>
#include<vector>
#include<list>
#include<map>
#include<set>
#include<unordered_map>
#include<unordered_set>
#include<algorithm>
#include<utility>
#include<functional>
#include<regex>

#include<cstdlib>
#include "log.h"
#include "Error_Message.h"
#include "Translate_Function.h"
#include "D:\\Code\\C++\\Headers\zle_STL.h"
#include "Main_Function.h"
#include "prehead.h"
#include "global.h"


//S_ ��Source
//T_ ��Translated
//L_ ��Library

//using std::string;
//using std::vector;
//using std::cout;
//using std::cin;
//using std::endl;




//#define DVE
#define UTI



int main(int argc, char** argv) {


#ifdef UTI
	
	FileName = argv[1];
	
	std::string CFG = "zle.cfg";
	std::ifstream option(CFG);
	if (!option) {
		E_M::ConfingError;
	}
	else {
		std::cout << "Your Config is Recognized";
	}

	std::getline(option, FilePath);
	FilePath = zle::Slice(FilePath, 3, FilePath.size() - 1);
	std::string GCC;
	std::getline(option, GCC);
	GCC = zle::Slice(GCC, 4, GCC.size() - 1);

	if (argc < 2) {
		E_M::LackArg(argc);
	}
	E_M::NotZLE(argv[1]);
	//������GCC�̃p�X�擾
	std::string GPP;
	std::getline(option, GPP);
	//��������STANDARD�̒��g
	std::string temp35;
	std::getline(option, temp35);
	temp35 = zle::Slice(temp35, 6, temp35.size() - 1);
	std::cout << "STANDARD contents:" << temp35 << std::endl;
	std::vector<std::string> STD_C;
	std::string temp44;
	for (int s = 0; s < temp35.size(); s++) {
		if (temp35[s] == ',') {
			STD_C.emplace_back(temp44);
			temp44 = temp44.erase(0);
		}
		else if (s+1==temp35.size()) {
			temp44 += temp35[s];
			STD_C.emplace_back(temp44);
			break;
		}
		else {
			temp44 += temp35[s];
		}
	}
	//zle���C�u����
	
	std::getline(option, STD_Z);
	STD_Z = zle::Slice(STD_Z, 6, STD_Z.size() - 1);
	std::getline(option, ADD_Z);
	ADD_Z = zle::Slice(ADD_Z, 6, ADD_Z.size() - 1);
#endif

	
	//E_M::NotCPP(argv[3]);

#ifdef DVE
	 FilePath= R"(C:\Users\mitsui\Desktop\Zle\Code\Main\)";
	 FileName = "test.zle";
	E_M::NotZLE(FileName);
	STD_C.resize(4);
	STD_C[0] = "iostream";
	STD_C[1] = "string";
	STD_C[2] = "vector";
	STD_C[3] = "fstream";

	 STD_Z = "C:\\Users\\mitsui\\Desktop\\Zle\\Code\\Library\\Standard\\";
	 ADD_Z = "C:\\Users\\mitsui\\Desktop\\Zle\\Code\\Library\\Additional\\";

#endif 



	std::ifstream S_File(FilePath+FileName, std::ios::binary);
	std::cout << FilePath + FileName << std::endl;

	FileName = zle::Slice(FileName, 0, FileName.size() - 4)+"cpp";
	std::ofstream T_File(FilePath+FileName, std::ios::trunc);

	if (!S_File) {
		E_M::FailedOpen();
	}

	if (!T_File) {
		E_M::FailedCreate();
	}


	while (!S_File.eof()) {
		std::string EachLine;
		std::getline(S_File,EachLine);
	

		Code.emplace_back(EachLine);
		std::cout << Code[Code.size()-1] << std::endl;
	}

	

	//�����������炪�G�O����������
	//��Ƀv���v�� import��define��ϊ�
	for (int L = 0; L < Code.size(); L++) {
		MacroPre(Code[L], L, T_File,STD_C);

		T_F::MacroSTD(Code[L]);
	}

	//�}�N���W�J��̏����@�܂�u���b�N�W�J���撣�낤�Ƃ�

	extern std::vector<std::string> T_Code;
	T_Code.resize(Code.size());

	M_F::MainFunciton(T_Code, Code, T_File, FORCOUNTER);

	for (int G = 0; G < T_Code.size(); G++) {
		std::cout << T_Code[G];
		T_File << T_Code[G] << std::flush;
	}
	T_File.close();


#ifdef UTI

	std::cout << "Transpile Completed" << std::endl;
	std::string temp = zle::Slice(FileName, 0,FileName.size() - 5);
	GCC += "g++.exe";

	
	GPP = zle::Slice(GPP, 3, GPP.size() - 1);
	GPP = GCC+ " -o " +GPP+ temp +" "+GPP+ FileName;

	std::cout << GPP << std::endl;

	if (!std::system(GPP.c_str())){
		std::cout << "G++ Compile Succeed" << std::endl;
	}
	else {
		std::cout << "G++ Compile Failed" << std::endl;
	}
#endif	

	return 0;
}