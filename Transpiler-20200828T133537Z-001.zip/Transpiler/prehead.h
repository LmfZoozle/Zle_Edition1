#pragma once
#include <iostream>
#include<fstream>
#include<sstream>

#include<string>
#include<vector>
#include<list>
#include<map>
#include<set>
#include<unordered_map>
#include<unordered_set>
#include "Translate_Function.h"
#include  "Error_Message.h"
#include "global.h"


#define NM "NOTHNIGMATCH"
#define NLS "NULLSENTENCE"
#define RE return 999;

void MacroPre(std::string& target, int LINE, std::ofstream& FILE, std::vector<std::string> STD);


void MacroPre(std::string& target, int LINE, std::ofstream& FILE, std::vector<std::string> STD) {
	int position;
	if (T_F::Search(target, "import", position) != -1) {
		if (T_F::Search(target, ';')) {
			E_M::ImportSemi(LINE);
		}

		std::string LibName = T_F::Erase(target, "import");
		LibName = zle::Replace(LibName, ' ');
		LibName = zle::Replace(LibName, '\t');
		LibName = zle::Replace(LibName, '\n');
		LibName = zle::Replace(LibName, '\r');
		if (LibName.find("STANDARD") != std::string::npos) {
			std::cout << "STANDARD include" << std::endl;
			for (int g = 0; g < STD.size(); g++) {
				FILE << "#include<" << STD[g] << ">" << std::endl;
			}
			target = NLS;
			return;
		}
		else {
			std::cout << "import" << std::endl;

			FILE << "#include<" << LibName << ">" << std::endl;
			target = NLS;
			return;
		}
	}
	//���������t���p�X�ł��ق�
	if (T_F::Search(target, "myport_full", position) != -1) {
		if (T_F::Search(target, ';')) {
			E_M::MyportSemi(LINE);
		}

		std::string LibName = T_F::Erase(target, "myport_full");
		LibName = zle::Replace(LibName, ' ');
		LibName = zle::Replace(LibName, '\t');
		LibName = zle::Replace(LibName, '\n');
		LibName = zle::Replace(LibName, '\r');

		if (LibName[LibName.size() - 1] == 'h') {
			std::cout << "myport_full:C++" << std::endl;

			FILE << "#include \"" << LibName << "\"\n" << std::endl;
			target = NLS;
			return;
		}
		else {
			//�܂� .zle�t�@�C��
			std::cout << LibName << std::endl;
			//exit(2);
			std::ifstream fullzel(LibName);
			if (!fullzel) {
				E_M::FullHeaderFailed_Read(LibName);
			}
			std::vector<std::string> rest;

			while (!fullzel.eof()) {
				std::string EachLine;
				std::getline(fullzel, EachLine);


				rest.emplace_back(EachLine);
				std::cout << rest[rest.size() - 1] << std::endl;
			}

			std::vector<std::string> T_rest;
			T_rest.resize(Code.size());
			std::string name = LibName;
			int find = 0;
			for (int c = 0; c < name.size(); c++) {
				if (name[c] == '\\') {
					find = c + 1;
				}
			}
			name = zle::Slice(name, find, name.size() - 5) + ".h";
			std::cout << ADD_Z << std::endl;
//			exit(1);
			std::ofstream FZH(ADD_Z + name);
			if (!FZH) {
				E_M::FullHeaderFailed_Write(ADD_Z + name);
			}
			else {
				std::cout << "succeed" << std::endl;
				std::cout << ADD_Z + name << std::endl;
			}
			for (int L = 0; L < rest.size(); L++) {
				MacroPre(rest[L], L, FZH, STD_C);

				T_F::MacroSTD(rest[L]);
			}
			M_F::MainFunciton(T_rest, rest, FZH, FORCOUNTER);
			for (int G = 0; G < T_rest.size(); G++) {
				std::cout << T_rest[G];
				FZH << T_rest[G] << std::flush;
			}
			std::cout << "myport_full:zle"<<std::endl;
			T_Code.emplace_back("#include \"" + ADD_Z+ name + "\"\n");
			target = NLS;
			return;
		}
	}


	//�����������C�u�����ɂ���ق�
	if (T_F::Search(target, "myport", position) != -1) {
		if (T_F::Search(target, ';')) {
			E_M::MyportSemi(LINE);
		}

		std::string LibName = T_F::Erase(target, "myport");
		LibName = zle::Replace(LibName, ' ');
		LibName = zle::Replace(LibName, '\t');
		LibName = zle::Replace(LibName, '\n');
		LibName = zle::Replace(LibName, '\r');

		std::cout << "myport" << std::endl;


		if (LibName[LibName.size() - 1] == 'h') {
			std::cout << "myport_in_Library:C++" << std::endl;

			FILE << "#include \"" <<ADD_Z+ LibName << "\"" << std::endl;
			target = NLS;
			return;
		}
		else {
			if (std::ifstream(ADD_Z + LibName)) {
				std::cout << LibName << std::endl;
				//exit(2);
				std::ifstream libzle(ADD_Z+LibName);
				if (!libzle) {
					E_M::LibraryHeaderFailed_Read(LibName);
				}
				std::vector<std::string> rest;

				while (!libzle.eof()) {
					std::string EachLine;
					std::getline(libzle, EachLine);


					rest.emplace_back(EachLine);
					std::cout << rest[rest.size() - 1] << std::endl;
				}

				std::vector<std::string> T_rest;
				T_rest.resize(Code.size());
				std::string name = LibName;

				name = zle::Slice(name, 0, name.size() - 5) + ".h";

				std::ofstream LAZH(ADD_Z + name);
				if (!LAZH) {
					E_M::LibraryHeaderFailed_Write(ADD_Z + name);
				}
				else {
					std::cout << "succeed" << std::endl;
					std::cout << ADD_Z + name << std::endl;
				}
				for (int L = 0; L < rest.size(); L++) {
					MacroPre(rest[L], L, LAZH, STD_C);

					T_F::MacroSTD(rest[L]);
				}
				M_F::MainFunciton(T_rest, rest, LAZH, FORCOUNTER);
				for (int G = 0; G < T_rest.size(); G++) {
					std::cout << T_rest[G];
					LAZH << T_rest[G] << std::flush;
				}
				std::cout << "myport_in_Library:zle"<<std::endl;
				T_Code.emplace_back("#include \"" + ADD_Z + name + "\"\n");
				target = NLS;
				return;

			}
			else if (std::ifstream(STD_Z + LibName)) {
					std::cout << LibName << std::endl;
					//exit(2);
					std::ifstream libzle(STD_Z + LibName);
					if (!libzle) {
						E_M::LibraryHeaderFailed_Read(LibName);
					}
					std::vector<std::string> rest;

					while (!libzle.eof()) {
						std::string EachLine;
						std::getline(libzle, EachLine);


						rest.emplace_back(EachLine);
						std::cout << rest[rest.size() - 1] << std::endl;
					}

					std::vector<std::string> T_rest;
					T_rest.resize(Code.size());
					std::string name = LibName;

					name = zle::Slice(name, 0, name.size() - 5) + ".h";

					std::ofstream LAZH(STD_Z + name);
					if (!LAZH) {
						E_M::LibraryHeaderFailed_Write(STD_Z + name);
					}
					else {
						std::cout << "succeed" << std::endl;
						std::cout << STD_Z + name << std::endl;
					}
					for (int L = 0; L < rest.size(); L++) {
						MacroPre(rest[L], L, LAZH, STD_C);

						T_F::MacroSTD(rest[L]);
					}
					M_F::MainFunciton(T_rest, rest, LAZH, FORCOUNTER);
					for (int G = 0; G < T_rest.size(); G++) {
						std::cout << T_rest[G];
						LAZH << T_rest[G] << std::flush;
					}
					std::cout << "myport_in_Library:zle"<<std::endl;
					T_Code.emplace_back("#include \"" + STD_Z + name + "\"\n");
					target = NLS;
					return;
				
			}
			else {
				E_M::NoLibraryHeader(LibName);
			}
		}
	}

	if (T_F::Search(target, "def", position) != -1) {
		if (T_F::Search(target, ';')) {
			E_M::DefineSemi(LINE);
		}

		std::string DefName = T_F::Erase(target, "def");
		DefName = zle::Replace(DefName, '\n');
		DefName = zle::Replace(DefName, '\r');

		std::cout << "def" << std::endl;

		FILE << "#define" << DefName << std::endl;
		target = NLS;
		return;
	}

	if (T_F::Search(target, "namespace", position) != -1) {
		std::string NameName = target;
		NameName = zle::Replace(NameName, '\n');
		NameName = zle::Replace(NameName, '\r');
		NameName = zle::Replace(NameName, ' ');
		NameName = zle::Replace(NameName, ':', ' ');
		NameName = "using " + NameName + ";";
		std::cout << "namespace" << std::endl;
		FILE << NameName << std::endl;
		target = NLS;
		return;
	}
}