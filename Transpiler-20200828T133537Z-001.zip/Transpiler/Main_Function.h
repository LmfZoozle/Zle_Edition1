#pragma once

#include <iostream>
#include<fstream>
#include<sstream>

#include<string>
#include<vector>
#include<list>
#include<map>
#include<set>
#include<unordered_map>
#include<unordered_set>
#include "Translate_Function.h"
#include  "Error_Message.h"
#include "global.h"
//#define NLS "NULLSENTENCE"



namespace M_F{
	void MainFunciton(std::vector<std::string>& T_Code, std::vector<std::string>& Code,std::ofstream& T_File,int& FORCOUNTER);
}

void M_F::MainFunciton(std::vector<std::string>& T_Code,std::vector<std::string>&Code, std::ofstream& T_File, int& FORCOUNTER) {

	for (int L = 0; L < Code.size(); L++) {
		int position;
		int tabvalue = 0;
	PROCESS:
		if (T_F::Search(Code[L], "!RECOG!", position) != -1) {
			std::string Recog = T_F::Erase(Code[L], "!RECOG!");
			Recog = "*/" + Recog;
			Recog = Recog + "/*";
			Code[L] = Recog;
			goto PROCESS;
		}


		else if (T_F::Search(Code[L], "!CPP!", position) != -1) {
			for (int x = 0; x < Code[L + 1].size(); x++) {
				if (Code[L + 1][x] != ' ') {
					break;
				}
				tabvalue++;
			}

			for (int T = 0; L + T < Code.size(); T++) {
				if (Code[L + T].size() < tabvalue) {

				}
				else if ((Code[L + T][tabvalue - 1] == ' ') && (Code[L + T][tabvalue - 2] == ' ')) {
					T_Code.emplace_back(Code[L + T]);
					Code[L + T] = NLS;
				}
				else {
					break;
				}
			}
			continue;
		}

		else if (T_F::Search(Code[L], "else if", position) != -1) {
			int tabvalue = 0;
			for (int x = 0; x < Code[L + 1].size(); x++) {
				if (Code[L + 1][x] != ' ') {
					break;
				}
				tabvalue++;
			}
			for (int y = L + 2; y < Code.size(); y++) {
				if (Code[y].size() < tabvalue) {

				}
				else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {

				}
				else {

					if(Code[L].find('@')!=std::string::npos){
						std::string temp = zle::Slice(Code[L], Code[L].find('@')+1, Code[L].size() - 1);
						temp = zle::Once_Replace(temp, '\n');
						temp = zle::Once_Replace(temp, '\r');
						Code[L] = zle::Slice(Code[L], 0, Code[L].find('@') - 1)+"\n";
						Code[y - 1] += "  }\n"+temp+":"+"\r";
						std::cout << "Escape label" << std::endl;
						break;
					}
					else {
						Code[y - 1] += "  }\n";
						break;
					}
				}
			}



			int ifend = 0;
			std::string ifstr = Code[L];
			for (int s = 0; Code[L].size(); s++) {
				if (ifstr[s] == 'f') {
					ifend = s + 1;
					break;
				}
			}
			ifstr.insert(ifend, "(");
			ifstr = T_F::ChtoStr(ifstr, ':', "){");
			T_Code.emplace_back(ifstr);
			std::cout << "else_if" << std::endl;
			Code[L] = NLS;
			continue;



		}
		else if (T_F::Search(Code[L], "escape", position) != -1) {
			Code[L] = T_F::AllFormat(Code[L], "escape", "goto");
			Code[L] = zle::Once_Replace(Code[L], '@');
			T_Code.emplace_back(Code[L]);
			Code[L] = NLS;
			std::cout << "Escape" << std::endl;
			continue;
		}


		else if (T_F::Search(Code[L], "if", position) != -1) {

			if (T_F::PatternIF(Code, L)) {
				int tabvalue = 0;
				for (int x = 0; x < Code[L + 1].size(); x++) {
					if (Code[L + 1][x] != ' ') {
						break;
					}
					tabvalue++;
				}
				for (int y = L + 2; y < Code.size(); y++) {
					if (Code[y].size() < tabvalue) {

					}
					else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {

					}

					else {
						if (Code[L].find('@') != std::string::npos) {
							std::string temp = zle::Slice(Code[L], Code[L].find('@')+1, Code[L].size() - 1);
							temp = zle::Once_Replace(temp, '\n');
							temp = zle::Once_Replace(temp, '\r');
							Code[L] = zle::Slice(Code[L], 0, Code[L].find('@') - 1) + "\n";
							Code[y - 1] += "  }\n" + temp + ":" + "\r";
							std::cout << "Escape label" << std::endl;
							break;
						}
						else {
							Code[y - 1] += "  }\n";
							break;
						}
					}
				}



				int ifend = 0;
				std::string ifstr = Code[L];
				for (int s = 0; Code[L].size(); s++) {
					if (ifstr[s] == 'f') {
						ifend = s + 1;
						break;
					}
				}
				ifstr.insert(ifend, "(");
				ifstr = T_F::ChtoStr(ifstr, ':', "){");
				T_Code.emplace_back(ifstr);
				std::cout << "double_if" << std::endl;
				Code[L] = NLS;
				continue;
			}
			else {
				int ifend = 0;
				std::string ifstr = Code[L];
				for (int s = 0; s < Code[L].size(); s++) {
					if (ifstr[s] == 'f') {
						ifend = s + 1;
						break;
					}
				}
				ifstr.insert(ifend, "(");
				ifstr = T_F::ChtoStr(ifstr, ':', ")\n");
				T_Code.emplace_back(ifstr);
				std::cout << "single_if" << std::endl;
				Code[L] = NLS;
				continue;
			}
		}		

		else if (T_F::Search(Code[L], "else", position) != -1) {
		
		int tabvalue = 0;
		for (int x = 0; x < Code[L + 1].size(); x++) {
			if (Code[L + 1][x] != ' ') {
				break;
			}
			tabvalue++;
		}
		for (int y = L + 2; y < Code.size(); y++) {
			if (Code[y].size() < tabvalue) {

			}
			else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {

			}
			else {
				if (Code[L].find('@') != std::string::npos) {
					std::string temp = zle::Slice(Code[L], Code[L].find('@')+1, Code[L].size() - 1);
					temp = zle::Once_Replace(temp, '\n');
					temp = zle::Once_Replace(temp, '\r');
					Code[L] = zle::Slice(Code[L], 0, Code[L].find('@') - 1) + "\n";
					Code[y - 1] += "  }\n" + temp + ":" + "\r";
					std::cout << "Escape label" << std::endl;
					break;
				}
				else {
					Code[y - 1] += "  }\n";
					break;
				}
			}
		}

		std::string ifstr = Code[L];

		ifstr = zle::Replace(ifstr, ':', '{');
		T_Code.emplace_back(ifstr);
		std::cout << "else" << std::endl;
		Code[L] = NLS;
		continue;

		}



		else if (T_F::Search(Code[L], "while", position) != -1) {
			int tabvalue = 0;
			for (int x = 0; x < Code[L + 1].size(); x++) {
				if (Code[L + 1][x] != ' ') {
					break;
				}
				tabvalue++;
			}
			for (int y = L + 2; y < Code.size(); y++) {
				if (Code[y].size() < tabvalue) {

				}
				else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {

				}
				else {
					if (Code[L].find('@') != std::string::npos) {
						std::string temp = zle::Slice(Code[L], Code[L].find('@')+1, Code[L].size() - 1);
						temp = zle::Once_Replace(temp, '\n');
						temp = zle::Once_Replace(temp, '\r');
						Code[L] = zle::Slice(Code[L], 0, Code[L].find('@') - 1) + "\n";
						Code[y - 1] += "  }\n" + temp + ":" + "\r";
						std::cout << "Escape label" << std::endl;
						break;
					}
					else {
						Code[y - 1] += "  }\n";
						break;
					}
				}
			}



			int ifend = 0;
			std::string ifstr = Code[L];
			for (int s = 0; s < Code[L].size(); s++) {
				if (ifstr[s] == 'e') {
					ifend = s + 1;
					break;
				}
			}
			ifstr.insert(ifend, "(");
			ifstr = T_F::ChtoStr(ifstr, ':', "){");
			T_Code.emplace_back(ifstr);
			std::cout << "double_while" << std::endl;
			Code[L] = NLS;
			continue;
		}

		else if (T_F::Search(Code[L], "func", position) != -1) {

			int tabvalue = 0;
			for (int x = 0; x < Code[L + 1].size(); x++) {
				if (Code[L + 1][x] != ' ') {
					break;
				}
				tabvalue++;
			}
			//	std::cout << Code[L+1] << std::endl<< "tab��" << tabvalue << std::endl;
			for (int y = L + 1; y < Code.size(); y++) {
				if (y + 1 == Code.size()) {
					Code[y] += "  }\r";
					break;
				}
				else if (Code[y].size() < tabvalue) {
					//std::cout << "�k���|���" << std::endl;
					std::cout << "NULL AVOID" << std::endl;
				}
				else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {

				}
				else {
					Code[y - 1] += "  }\r";
					break;
				}

			}



			int ifend = 0;
			std::string ifstr = Code[L];
			//std::cout << "����\n" << Code[L];
			ifstr = T_F::Erase(ifstr, "func ");
			//ifstr = zle::Slice(ifstr, 5, ifstr.size() - 1);
			//std::cout << ifstr<<std::endl<< "���ꂪ�u����\n" << std::flush;
			for (int s = 0; s < Code[L].size(); s++) {
				if (ifstr[s] == ')') {
					ifend = s + 1;
					break;
				}
			}
			//ifstr.insert(ifend, " {");
			T_File << zle::Replace(ifstr, ':', ';') << std::endl;

			ifstr = zle::Replace(ifstr, ':', '{');
			T_Code.emplace_back(ifstr);
			std::cout << "double_func" << std::endl;
			Code[L] = NLS;
			continue;

		}

		else if (T_F::Search(Code[L], "class", position) != -1) {
			Code[L] = zle::Replace(Code[L], '\n');
			Code[L] = zle::Replace(Code[L], '\r');
			Code[L] = zle::Replace(Code[L], ':', '{');
			Code[L] += "\r";
			int tabvalue = 0;
			for (int x = 0; x < Code[L + 1].size(); x++) {
				if (Code[L + 1][x] != ' ') {
					break;
				}
				tabvalue++;
			}
			for (int y = L + 2; y < Code.size(); y++) {
				if (Code[y].size() < tabvalue) {

				}
				else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {
				}
				else {
					Code[y - 1] += "  };\n";
					break;
				}
			}


			T_Code.emplace_back(Code[L]);
			std::cout << "double_class" << std::endl;
			Code[L] = NLS;
			continue;
		}

		else if (T_F::Search(Code[L], "for", position) != -1) {
			if (T_F::PatternFor(Code[L]) == 1) {
				std::string FC = "FORCOUNT" + std::to_string(FORCOUNTER);
				std::string times;
				std::string ValueName;

				for (int c = 0; c < Code[L].size(); c++) {
					if (zle::Slice(Code[L], c, c + 1) == "as") {
						c += 3;
						while (1) {
							if (Code[L][c] == ' ') {
								//				std::cout << ValueName << "���ϐ����ŃT�C�Y��" << ValueName.size() << std::endl;
								std::cout << "ForVarName is " << ValueName << " size =" << ValueName.size() << std::endl;
								break;
							}
							else {
								ValueName += Code[L][c];
							}
							c++;
						}
						break;
					}
				}

				for (int c = 0; c < Code[L].size(); c++) {
					if (Code[L][c] == '(') {
						for (int g = c + 1; g < Code[L].size(); g++) {
							if (Code[L][g] == ')') {
								break;
							}
							else {
								times += Code[L][g];
							}
						}
						break;
					}
				}
				T_Code.emplace_back("for(int " + FC + "=0; " + FC + "<" + times + "; " + FC + "++){\r");
				FORCOUNTER++;

				for (int x = 0; x < Code[L + 1].size(); x++) {
					if (Code[L + 1][x] != ' ') {
						break;
					}
					tabvalue++;
				}
				for (int y = L + 1; y < Code.size(); y++) {
					if (Code[y].size() < tabvalue) {

					}
					else if ((Code[y][tabvalue - 1] != ' ') || (Code[y][tabvalue - 2] != ' ')) {
						if (Code[L].find('@') != std::string::npos) {
							std::string temp = zle::Slice(Code[L], Code[L].find('@')+1, Code[L].size() - 1);
							temp = zle::Once_Replace(temp, '\n');
							temp = zle::Once_Replace(temp, '\r');
							Code[L] = zle::Slice(Code[L], 0, Code[L].find('@') - 1) + "\n";
							Code[y - 1] += "  }\n" + temp + ":" + "\r";
							std::cout << "Escape label" << std::endl;
							break;
						}
						else {
							Code[y - 1] += "  }\n";
							break;
						}
					}
					else {

						std::string::size_type findAS = Code[y].find(ValueName);
						while (findAS != std::string::npos) {
							//Code[y] = zle::Replace(Code[y], ValueName, FC);
							std::string tempstr = zle::Slice(Code[y], findAS + ValueName.size(), Code[y].size() - 1);
							Code[y] = zle::Slice(Code[y], 0, findAS - 1);
							Code[y] += tempstr;
							Code[y] = Code[y].insert(findAS, FC);

							//	std::cout << std::endl;
							//	std::cout << "�[���ϐ�" << std::endl;
							findAS = Code[y].find(ValueName);
						}
						std::cout << "Replaced:" << std::flush << Code[y] << std::endl;
					}
				}
				Code[L] = NLS;
				std::cout << "for_range" << std::endl;
				continue;

			}
			else if (T_F::PatternFor(Code[L]) == 0) {



				Code[L] = zle::Replace(Code[L], ':');
				std::string::size_type finder = Code[L].find("of");

				std::string tempstr = zle::Slice(Code[L], finder + 2, Code[L].size() - 1);
				Code[L] = zle::Slice(Code[L], 0, finder - 1);
				Code[L] += tempstr;
				Code[L] = Code[L].insert(finder, ":");



				Code[L] = zle::Once_Replace(Code[L], 'f');
				Code[L] = zle::Once_Replace(Code[L], 'o');
				Code[L] = zle::Once_Replace(Code[L], 'r');
				Code[L] = zle::Slice(Code[L], 0, Code[L].size() - 2);
				T_Code.emplace_back("for(" + Code[L] + "){\r");

				for (int x = 0; x < Code[L + 1].size(); x++) {
					if (Code[L + 1][x] != ' ') {
						break;
					}
					tabvalue++;
				}
				for (int y = L + 1; y < Code.size(); y++) {
					if (Code[y].size() < tabvalue) {

					}
					else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {

					}
					else {
						if (Code[L].find('@') != std::string::npos) {
							std::string temp = zle::Slice(Code[L], Code[L].find('@')+1, Code[L].size() - 1);
							temp = zle::Once_Replace(temp, '\n');
							temp = zle::Once_Replace(temp, '\r');
							Code[L] = zle::Slice(Code[L], 0, Code[L].find('@') - 1) + "\n";
							Code[y - 1] += "  }\n" + temp + ":" + "\r";
							std::cout << "Escape label" << std::endl;
							break;
						}
						else {

							Code[y - 1] += "  }\n";
							break;
						}
					}
				}

				Code[L] = NLS;
				std::cout << "for_of" << std::endl;
				continue;

			}
			else if (T_F::PatternFor(Code[L]) == -1) {
				std::string FC = "FORCOUNT" + std::to_string(FORCOUNTER);
				int colon = 0;
				for (int k = 0; k < Code[L].size(); k++) {
					if (Code[L][k] == ':') {
						if (colon == 2) {
							Code[L][k] = ')';
							break;
						}
						else {
							Code[L][k] = ';';
							colon++;
						}

					}
				}
				Code[L] = zle::Once_Replace(Code[L], 'f');
				Code[L] = zle::Once_Replace(Code[L], 'o');
				Code[L] = zle::Once_Replace(Code[L], 'r');


				if (Code[L].find('@') != std::string::npos) {
					std::string temp = zle::Slice(Code[L], 0, Code[L].find('@') - 1) + "\n";
					std::cout << "Escape label" << std::endl;
					T_Code.emplace_back("for(" + temp + "{\r");
				}
				else {
					T_Code.emplace_back("for(" + Code[L] + "{\r");
				}
				FORCOUNTER++;

				for (int x = 0; x < Code[L + 1].size(); x++) {
					if (Code[L + 1][x] != ' ') {
						break;
					}
					tabvalue++;
				}
				for (int y = L + 1; y < Code.size(); y++) {
					if (Code[y].size() < tabvalue) {

					}
					else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {

					}
					else {
						if (Code[L].find('@') != std::string::npos) {
							std::string temp = zle::Slice(Code[L], Code[L].find('@')+1, Code[L].size() - 1);
							temp = zle::Once_Replace(temp, '\n');
							temp = zle::Once_Replace(temp, '\r');
							Code[y - 1] += "  }\n" + temp + ":" + "\r";
							std::cout << "Escape label" << std::endl;
							break;
						}
						else {
							Code[y - 1] += "  }\r";
							break;
						}
					}
				}
				Code[L] = NLS;
				std::cout << "for_normal" << std::endl;
				continue;


			}
			else {
				E_M::UnknownFor(L);
			}

		}

		else if (Code[L].find("temp") != std::string::npos) {



			Code[L] = T_F::OnceFormat(Code[L], "temp", "template<class ");
			std::string::size_type findcolo = Code[L].find(':');
			if (findcolo == std::string::npos) {
				void E_M::TemplateSynSin(int line);
			}
			Code[L][findcolo] = '>';
			for (int c = 0; c < findcolo; c++) {
				if (Code[L][c] == ',') {
					Code[L] = Code[L].insert(c + 1, "class ");
				}
			}

			T_File << zle::Replace(Code[L], ':', ';') << std::endl;


			int tabvalue = 0;
			for (int x = 0; x < Code[L + 1].size(); x++) {
				if (Code[L + 1][x] != ' ') {
					break;
				}
				tabvalue++;
			}
			for (int y = L + 1; y < Code.size(); y++) {
				if (y + 1 == Code.size()) {
					Code[y] += "  }\r";
					break;
				}
				else if (Code[y].size() < tabvalue) {
					//	std::cout << "�k���|���" << std::endl;
					std::cout << "NULL AVOID" << std::endl;
				}
				else if ((Code[y][tabvalue - 1] == ' ') && (Code[y][tabvalue - 2] == ' ')) {

				}
				else {
					Code[y - 1] += "  }\r";
					break;
				}
			}

			T_Code.emplace_back(zle::Replace(Code[L], ':', '{'));

			Code[L] = NLS;
			std::cout << "temp_func" << std::endl;
			continue;
		}


		else  if (Code[L] == NLS) {

		}

		else {
			T_Code.emplace_back(Code[L]);
		}


	}


}